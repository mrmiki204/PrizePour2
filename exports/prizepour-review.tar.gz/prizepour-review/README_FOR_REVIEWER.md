# PrizePour — code review bundle

This project is a pnpm monorepo. Folders renamed for review convenience:

| In this bundle      | Actual repo path                   |
|---------------------|------------------------------------|
| `client/`           | `artifacts/whiskey-giveaway/`      |
| `server/`           | `artifacts/api-server/`            |
| `shared/db/`        | `lib/db/`                          |
| `shared/api-spec/`  | `lib/api-spec/` (OpenAPI source)   |
| `shared/api-zod/`   | `lib/api-zod/` (generated)         |
| `shared/api-client-react/` | `lib/api-client-react/` (generated) |

## Stack
- React + Vite (client), Express 5 + Drizzle (server), PostgreSQL
- TypeScript 5.9, Tailwind, shadcn/ui, framer-motion, wouter, TanStack Query
- Stripe Checkout (redirect) for payments
- Codegen: Orval (OpenAPI → React Query hooks + Zod schemas)

## Notes
- Image binaries removed to keep the bundle small.
- `node_modules/`, `dist/`, build output excluded.
- Source of truth for API contract: `shared/api-spec/openapi.yaml`
- DB schema source of truth: `shared/db/`
- See `replit.md` for product context, architecture decisions, and open decisions.
