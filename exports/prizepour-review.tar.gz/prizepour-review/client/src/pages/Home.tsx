import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { CountdownTimer } from '@/components/giveaway/CountdownTimer';
import { Button } from '@/components/ui/button';
import { ArrowRight, Trophy, ShieldCheck, Users, Ticket, Star, Lock, Package, ChevronDown, ChevronUp } from 'lucide-react';
import heroImg from '@/assets/images/hero.png';
import { getGiveawayImage, daysUntil, getGiveawayBottles } from '@/data/giveaways';
import { useListGiveaways } from '@workspace/api-client-react';


const FAQS = [
  {
    q: "Is this legal?",
    a: "Yes. All draws are skill-testing question competitions, fully compliant with UK promotional contest law. No purchase necessary — free entry by mail-in is always available."
  },
  {
    q: "How are winners selected?",
    a: "Winners are selected via a cryptographically secure RNG at the exact draw close time. The process is independently witnessed and recorded."
  },
  {
    q: "How is my prize delivered?",
    a: "Every prize is professionally packed with insurance and shipped via tracked courier. We cover all applicable duties and taxes to your door."
  },
  {
    q: "How do I know the prize is genuine?",
    a: "Every item in our inventory is sourced from authorised retailers and verified by our team before listing. We never ship grey-market goods."
  }
];

function scrollTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
}

function BottleList({ bottles }: { bottles: { name: string }[] }) {
  const [expanded, setExpanded] = useState(false);
  const COLLAPSED = 6;
  const needsToggle = bottles.length > COLLAPSED;
  const shown = expanded || !needsToggle ? bottles : bottles.slice(0, COLLAPSED);
  const hiddenCount = bottles.length - COLLAPSED;
  return (
    <div className="space-y-1.5 pt-2">
      <AnimatePresence initial={false}>
        {shown.map((bottle, i) => (
          <motion.div
            key={`${bottle.name}-${i}`}
            initial={i >= COLLAPSED ? { opacity: 0, height: 0 } : false}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="flex items-center text-xs font-serif py-1 border-b border-border/30 last:border-0 overflow-hidden"
          >
            <span className="text-foreground/70">{bottle.name}</span>
          </motion.div>
        ))}
      </AnimatePresence>
      {needsToggle && (
        <button
          type="button"
          onClick={() => setExpanded(v => !v)}
          className="mt-2 inline-flex items-center gap-1.5 text-[11px] font-serif uppercase tracking-[0.15em] text-primary hover:text-amber-300 transition-colors"
        >
          {expanded ? (
            <>Show less <ChevronUp className="w-3.5 h-3.5" /></>
          ) : (
            <>Show all {bottles.length} bottles (+{hiddenCount}) <ChevronDown className="w-3.5 h-3.5" /></>
          )}
        </button>
      )}
    </div>
  );
}

const fadeIn = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0 }
};

const slideVariants = {
  enter: (dir: number) => ({ x: dir > 0 ? '100%' : '-100%', opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir: number) => ({ x: dir < 0 ? '100%' : '-100%', opacity: 0 }),
};

export function Home() {
  const [, setLocation] = useLocation();
  const { data: giveaways, isLoading: giveawaysLoading } = useListGiveaways();
  const [showBanner, setShowBanner] = useState(true);
  const [featuredIndex, setFeaturedIndex] = useState(0);
  const [direction, setDirection] = useState(1);

  useEffect(() => {
    const t = setTimeout(() => setShowBanner(false), 3000);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!giveaways || giveaways.length <= 1) return;
    const id = setInterval(() => {
      setDirection(1);
      setFeaturedIndex(i => (i + 1) % giveaways.length);
    }, 5000);
    return () => clearInterval(id);
  }, [giveaways]);

  const featured = giveaways?.[featuredIndex];

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30">
      <AnimatePresence>
        {showBanner && (
          <motion.div
            initial={{ y: '-100%' }}
            animate={{ y: 0 }}
            exit={{ y: '-100%' }}
            transition={{ type: 'spring', stiffness: 260, damping: 28 }}
            className="fixed top-0 left-0 right-0 z-[100] flex items-center justify-center py-5 px-6"
            style={{ background: 'linear-gradient(135deg, #3d1a05 0%, #1c0c03 100%)', borderBottom: '2px solid #ea9237' }}
          >
            <div className="text-center">
              <p className="font-serif text-xs tracking-widest text-amber-500/70 uppercase mb-1">Draw Status</p>
              <p className="font-serif text-3xl md:text-5xl text-amber-400 tracking-wide">No Active Draws</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Navbar onScrollTo={scrollTo} />

      {/* ── Hero / Featured Draw ── */}
      <section className="relative pt-28 pb-16 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={heroImg} alt="" className="w-full h-full object-cover opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/85 to-background" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/10 mb-4">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-[10px] font-serif text-primary uppercase tracking-[0.2em]">Featured Draw</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-serif leading-tight">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-amber-200">Premium Spirit Giveaways</span>
            </h1>
            <p className="mt-5 mx-auto max-w-2xl text-base md:text-lg text-muted-foreground leading-relaxed">
              Exciting giveaways of premium spirits, exclusive distillery tours, professional bar equipment and more...
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative"
          >
            <div className="absolute -inset-6 bg-primary/15 blur-3xl rounded-full pointer-events-none" />

            <div className="relative bg-card/70 backdrop-blur border border-border rounded-sm shadow-2xl overflow-hidden">
              <AnimatePresence initial={false} custom={direction} mode="wait">
                <motion.div
                  key={featuredIndex}
                  custom={direction}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
                  className="grid lg:grid-cols-5"
                >
                  {/* ── Image (3/5) ── */}
                  <div className="lg:col-span-3 relative aspect-[4/3] lg:aspect-auto lg:min-h-[520px] overflow-hidden bg-black">
                    {featured && getGiveawayImage(featured.id, featured.imageUrl) ? (
                      <img
                        src={getGiveawayImage(featured.id, featured.imageUrl)}
                        alt={featured?.name}
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                    ) : (
                      <div className="absolute inset-0 bg-gradient-to-b from-amber-900/60 to-black flex items-center justify-center">
                        <Package className="w-24 h-24 text-primary/40" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
                    <div className="absolute inset-0 lg:bg-gradient-to-r lg:from-transparent lg:via-transparent lg:to-card/95" />

                    {/* Top badges */}
                    <div className="absolute top-4 left-4 right-4 flex justify-between items-start gap-2">
                      <span className="bg-primary text-primary-foreground text-[10px] font-serif uppercase tracking-[0.2em] px-3 py-1.5 rounded-sm shadow-lg">
                        Live Draw
                      </span>
                      {featured && (
                        <span className="bg-black/70 backdrop-blur text-white text-[10px] font-serif uppercase tracking-[0.2em] px-3 py-1.5 rounded-sm border border-white/10">
                          {getGiveawayBottles(featured.id).length} Bottles
                        </span>
                      )}
                    </div>

                    {/* Bottom name on mobile */}
                    {featured && (
                      <div className="absolute bottom-0 left-0 right-0 p-6 lg:hidden">
                        <p className="text-[10px] font-serif text-primary uppercase tracking-[0.2em] mb-2">Win The Special Collection</p>
                        <h2 className="text-2xl font-serif text-white leading-tight">{featured.name}</h2>
                      </div>
                    )}
                  </div>

                  {/* ── Info (2/5) ── */}
                  <div className="lg:col-span-2 p-6 lg:p-8 flex flex-col justify-between gap-6 bg-card/95">
                    <div className="space-y-4">
                      <div className="hidden lg:block">
                        <p className="text-[10px] font-serif text-primary uppercase tracking-[0.2em] mb-2">Win The Special Collection</p>
                        <h2 className="text-3xl xl:text-4xl font-serif text-white leading-tight">{featured?.name}</h2>
                      </div>

                      <div className="flex items-baseline gap-3 pt-2 border-t border-border/40">
                        <span className="text-[10px] font-serif text-muted-foreground uppercase tracking-[0.2em]">Prize Value</span>
                        <span className="text-3xl lg:text-4xl font-serif text-primary">{featured?.prizeValue}</span>
                      </div>

                      <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">{featured?.description}</p>
                    </div>

                    {/* Progress + countdown */}
                    {featured && (() => {
                      const pct = Math.min((featured.entryCount / featured.maxEntries) * 100, 100);
                      const remaining = featured.maxEntries - featured.entryCount;
                      return (
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between items-center text-[11px] font-serif mb-1.5">
                              <span className="text-muted-foreground uppercase tracking-widest">{featured.entryCount} / {featured.maxEntries} sold</span>
                              <span className={remaining <= 20 ? 'text-red-400' : 'text-primary'}>{remaining} left</span>
                            </div>
                            <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                              <motion.div
                                key={featuredIndex}
                                className={`h-full rounded-full ${pct >= 90 ? 'bg-red-500' : 'bg-primary'}`}
                                initial={{ width: 0 }}
                                animate={{ width: `${pct}%` }}
                                transition={{ duration: 0.9, ease: 'easeOut' }}
                              />
                            </div>
                          </div>

                          <div className="flex items-center justify-between gap-3 pt-2 border-t border-border/40">
                            <div>
                              <p className="text-[9px] font-serif text-muted-foreground uppercase tracking-[0.2em] mb-1">Draw Ends In</p>
                              <CountdownTimer daysToAdd={daysUntil(featured.drawDate)} />
                            </div>
                            <div className="text-right">
                              <p className="text-[9px] font-serif text-muted-foreground uppercase tracking-[0.2em] mb-1">Entry</p>
                              <p className="text-xl font-serif text-white">£4.99</p>
                            </div>
                          </div>

                          <Button
                            size="lg"
                            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold uppercase tracking-[0.15em] h-12"
                            onClick={() => setLocation(`/giveaway/${featured.id}`)}
                          >
                            Enter Now <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        </div>
                      );
                    })()}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Carousel controls */}
            {giveaways && giveaways.length > 1 && (
              <div className="flex items-center justify-center gap-2 mt-6">
                {giveaways.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setDirection(i > featuredIndex ? 1 : -1);
                      setFeaturedIndex(i);
                    }}
                    aria-label={`Show featured draw ${i + 1}`}
                    className={`rounded-full transition-all duration-300 h-1.5 ${i === featuredIndex ? 'bg-primary w-8' : 'bg-primary/30 hover:bg-primary/50 w-2'}`}
                  />
                ))}
              </div>
            )}

            <div className="flex justify-center mt-4">
              <Button variant="ghost" className="text-muted-foreground hover:text-primary text-xs font-serif uppercase tracking-[0.2em]" onClick={() => scrollTo('giveaways')}>
                View All Draws <ArrowRight className="w-3 h-3 ml-2" />
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── All Draws ── */}
      <section id="giveaways" className="py-24 max-w-7xl mx-auto px-6">
        <div className="mb-16">
          <p className="text-xs font-serif text-primary uppercase tracking-widest mb-3">Live Raffles</p>
          <h2 className="text-4xl font-serif mb-4">Active Draws</h2>
          <p className="text-muted-foreground max-w-xl">
            {giveaways && giveaways.length > 0
              ? `Enter for your chance to win.`
              : 'Check back soon for upcoming draws.'}
          </p>
        </div>

        {giveawaysLoading ? (
          <div className="space-y-8">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="h-64 bg-card border border-border/30 rounded-sm animate-pulse" />
            ))}
          </div>
        ) : !giveaways || giveaways.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground font-serif text-sm">
            No active draws at the moment. Check back soon.
          </div>
        ) : (
          <div className="space-y-8">
            {giveaways.map((g, idx) => {
              const pct = Math.min((g.entryCount / g.maxEntries) * 100, 100);
              const remaining = g.maxEntries - g.entryCount;
              const bottles = getGiveawayBottles(g.id);
              return (
                <motion.div
                  key={g.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: idx * 0.1 }}
                  className="bg-card border border-border rounded-sm overflow-hidden grid lg:grid-cols-2 hover:border-primary/40 transition-colors"
                >
                  {/* Left: bottle grid */}
                  {(() => {
                    const rowSize = Math.ceil(bottles.length / 2);
                    const rows = [bottles.slice(0, rowSize), bottles.slice(rowSize)];
                    return (
                      <div className="flex flex-col gap-px bg-border/30">
                        {rows.map((row, rowIdx) => (
                          <div key={rowIdx} className="flex gap-px justify-center">
                            {row.map((bottle, i) => (
                              <div
                                key={i}
                                className="aspect-[3/4] relative overflow-hidden group/bottle flex-none"
                                style={{ background: bottle.background, width: `${100 / rowSize}%` }}
                              >
                                <img
                                  src={bottle.image}
                                  alt={bottle.name}
                                  className="w-full h-full object-contain p-2 opacity-85 group-hover/bottle:opacity-100 group-hover/bottle:scale-105 transition-all duration-500"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                                <div className="absolute bottom-0 left-0 right-0 p-2 text-center">
                                  <p className="text-[9px] text-white/60 leading-tight line-clamp-1">{bottle.name}</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                    );
                  })()}

                  {/* Right: info panel */}
                  <div className="p-8 lg:p-10 flex flex-col justify-between gap-8">
                    <div className="space-y-4">
                      <div>
                        <span className="text-xs font-serif text-primary uppercase tracking-widest">Prize Selection</span>
                        <h3 className="text-3xl font-serif mt-2 mb-1">{g.name}</h3>
                        <p className="text-4xl font-serif text-primary">{g.prizeValue}</p>
                      </div>
                      <p className="text-muted-foreground text-sm leading-relaxed">{g.description}</p>

                      <BottleList bottles={bottles} />
                    </div>

                    <div className="space-y-6">
                      <div>
                        <div className="flex justify-between items-center text-xs font-serif mb-2">
                          <span className="text-muted-foreground">{g.entryCount} / {g.maxEntries} tickets sold</span>
                          <span className={remaining <= 20 ? 'text-red-400' : 'text-primary'}>{remaining} remaining</span>
                        </div>
                        <div className="h-2 bg-secondary rounded-full overflow-hidden">
                          <motion.div
                            className={`h-full rounded-full ${pct >= 90 ? 'bg-red-500' : 'bg-primary'}`}
                            initial={{ width: 0 }}
                            whileInView={{ width: `${pct}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1.2 }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <CountdownTimer daysToAdd={daysUntil(g.drawDate)} />
                        <div className="flex items-center gap-2 text-xs font-serif text-muted-foreground">
                          <Ticket className="w-3.5 h-3.5 text-primary" />
                          {pct.toFixed(0)}% sold
                        </div>
                      </div>

                      <Button
                        size="lg"
                        className="w-full h-14 bg-primary hover:bg-primary/90 text-primary-foreground uppercase tracking-widest text-sm font-serif"
                        onClick={() => setLocation(`/giveaway/${g.id}`)}
                      >
                        Enter the Draw — From £2.99
                      </Button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </section>

      {/* ── How it Works ── */}
      <section id="how-it-works" className="py-24 bg-card border-y border-border">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <p className="text-xs font-serif text-primary uppercase tracking-widest mb-3">The Process</p>
            <h2 className="text-4xl font-serif mb-4">Simple. Transparent. Fair.</h2>
            <p className="text-muted-foreground max-w-md mx-auto">Every draw follows the same iron-clad process, independently verified at each step.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            {[
              { icon: Ticket, step: '1', title: 'Secure Entry', body: 'Choose your prize and secure your entries. Each draw has a strict capacity limit to protect your odds.' },
              { icon: ShieldCheck, step: '2', title: 'Verified Draw', body: 'Winners are selected via a cryptographically secure RNG upon timer expiry, independently witnessed and recorded.' },
              { icon: Package, step: '3', title: 'Doorstep Delivery', body: 'Your prize is professionally packed with full insurance and shipped tracked to your door. Duties covered.' },
            ].map(({ icon: Icon, step, title, body }) => (
              <div key={step} className="text-center space-y-4 relative">
                <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center relative">
                  <Icon className="w-8 h-8 text-primary" />
                  <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-primary text-primary-foreground text-[10px] font-serif flex items-center justify-center">{step}</span>
                </div>
                <h3 className="text-xl font-serif">{title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Recent Additions ── */}
      <section id="winners" className="py-24 max-w-7xl mx-auto px-6">
        <div className="flex items-center gap-4 mb-4">
          <div className="h-px bg-border flex-1" />
          <p className="text-xs font-serif text-primary uppercase tracking-widest px-4">Latest Draws</p>
          <div className="h-px bg-border flex-1" />
        </div>
        <h2 className="text-3xl font-serif text-center mb-16">Recent Additions to Collections</h2>

        {(() => {
          const recentGiveaways = [...(giveaways ?? [])].reverse().slice(0, 4);
          if (giveawaysLoading) return (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-48 bg-card border border-border/30 rounded-sm animate-pulse" />
              ))}
            </div>
          );
          return (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {recentGiveaways.map((g, idx) => {
                const days = daysUntil(g.drawDate);
                const img = getGiveawayImage(g.id);
                return (
                  <motion.div
                    key={g.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="p-6 bg-card border border-border/50 rounded-sm text-center space-y-4 relative overflow-hidden cursor-pointer hover:border-primary/40 transition-colors"
                    onClick={() => setLocation(`/giveaway/${g.id}`)}
                  >
                    <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-primary/20 to-transparent opacity-50" />
                    {img
                      ? <img src={img} alt={g.name} className="w-16 h-16 object-contain mx-auto opacity-80" />
                      : <Trophy className="w-8 h-8 text-primary/60 mx-auto" />
                    }
                    <div>
                      <p className="font-serif text-base text-primary leading-tight line-clamp-2">{g.name}</p>
                      <p className="text-sm text-foreground mt-2 font-medium">{g.prizeValue}</p>
                      <p className="text-xs text-muted-foreground font-serif mt-1">
                        {days > 0 ? `Draw in ${days} day${days === 1 ? '' : 's'}` : 'Draw complete'}
                      </p>
                    </div>
                    <div className="flex justify-center gap-0.5">
                      {[...Array(5)].map((_, i) => <Star key={i} className="w-3 h-3 fill-primary text-primary" />)}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          );
        })()}
      </section>

      {/* ── Why PrizePour ── */}
      <section className="py-24 bg-card border-y border-border">
        <div className="max-w-5xl mx-auto px-6">
          <div>
            <div className="mb-12 text-center">
              <p className="text-xs font-serif text-primary uppercase tracking-widest mb-3">Why Us</p>
              <h2 className="text-4xl font-serif mb-6 leading-tight">The collector's edge you've been looking for.</h2>
              <p className="text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                PrizePour was built by enthusiasts for enthusiasts. We source direct from authorised retailers — no grey-market prizes, ever. Every draw is independently verified and every winner notified within 24 hours.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { icon: Lock, title: 'Cryptographic Draws', body: 'Winners selected by auditable RNG — no human involvement possible.' },
                  { icon: ShieldCheck, title: 'Verified Prizes', body: 'Every prize sourced from authorised retailers and checked before entering the draw.' },
                  { icon: Package, title: 'Fully Insured Shipping', body: 'Door-to-door tracked shipping with full replacement value covered.' },
                  { icon: Users, title: 'Community of Enthusiasts', body: 'Join collectors and spirits lovers who take their passion seriously.' },
                ].map(({ icon: Icon, title, body }) => (
                  <div key={title} className="flex gap-4">
                    <div className="shrink-0 w-10 h-10 rounded-sm bg-primary/10 border border-primary/20 flex items-center justify-center">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-serif text-sm mb-1">{title}</h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">{body}</p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── About / FAQ ── */}
      <section id="about" className="py-24 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <p className="text-xs font-serif text-primary uppercase tracking-widest mb-3">About PrizePour</p>
          <h2 className="text-4xl font-serif mb-4">Frequently Asked Questions</h2>
          <p className="text-muted-foreground max-w-md mx-auto">Everything you need to know before entering your first draw.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {FAQS.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card border border-border rounded-sm p-6"
            >
              <h4 className="font-serif text-lg mb-3 text-foreground">{faq.q}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{faq.a}</p>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-16">
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold uppercase tracking-wider" onClick={() => scrollTo('giveaways')}>
            Browse Active Draws
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
}
